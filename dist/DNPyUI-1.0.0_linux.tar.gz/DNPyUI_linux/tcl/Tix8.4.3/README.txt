
   Tix 8.4.3 for Tcl 8.4+
   
                       Tix Documentation Master Index

   This file is the master index of all the documentation included in
   this package. For additional information about Tix, please visit the
   Tix Home Page at

	http://tix.sourceforge.net/

   or join the mailing lists there.

     * ABOUT.html        A brief description of Tix.
     * docs/Release.html Release notes on this version of Tix.
     * unix/README.txt   Compiling and installing Tix under Unix.
     * win/README.txt    Compiling and installing Tix under Windows.
     * docs/html/TixUser/TixUser.html Tix Users's Guide.
     * Programming with Tix:
          + Tix Programmer's Guide.
          + Using Tix Stand Alone Modules (SAM).
     * docs/FAQ.html     The Tix Frequent Asked Questions.
     * ChangeLog.txt     Changes made to Tix since the previous release.
     * man/index.html    Programmer's Reference Manual.

   Versions of Tcl/Tk prior to 8.4 are no longer supported.
