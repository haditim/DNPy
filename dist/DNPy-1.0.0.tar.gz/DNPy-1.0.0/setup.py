from setuptools import setup, find_packages


setup(
    name="DNPy",
    scripts=['DNPyUI.py', 'functions.py'],
    version="1.0.0",
    author="M.Hadi Timachi",
    author_email="info@spintoolbox.com",
    description="a Python code package to evaluate continuous wave (CW) Overhauser dynamic nuclear polarization ("
                "ODNP) experiments",
    long_description=open("README.org").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    # Include additional files into the package
    include_package_data=True,
    # Details
    url="http://www.spintoolbox.com/en/offline-tools/dnpy/",
    license="LICENSE",
    # Dependent packages (distributions)
    install_requires=[
        "PyQt5", "numpy", "scipy", "matplotlib", "pillow",
    ],
    project_urls={
        "Home page": "http://www.spintoolbox.com/en/offline-tools/dnpy/",
        "Source Code": "https://github.com/haditim/DNPy",
    }
)






